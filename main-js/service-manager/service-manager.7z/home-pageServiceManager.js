function fnShowHomePage() {
    location.hash = "Home-page";
}
function fnGetHomePageFromServer(){
    var oXhr = new XMLHttpRequest();

    oXhr.open('GET', 'main.html');

    oXhr.onreadystatechange = function(oEv) {

        if (oEv.currentTarget.readyState == 4) {
            if (oEv.currentTarget.status != 200) {
                alert('file not found');
            } else {
                document.body.innerHTML = oEv.currentTarget.responseText;
            }
        }
  fnShowHomePage();  };



    oXhr.send();
}
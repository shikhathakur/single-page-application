function fnShowHumanFacePage() {
    location.hash = "Human-Face";
}
function fnGetHumanFaceFromServer()r(){
    var oXhr = new XMLHttpRequest();

    oXhr.open('GET', 'human-face.html');

    oXhr.onreadystatechange = function(oEv) {

        if (oEv.currentTarget.readyState == 4) {
            if (oEv.currentTarget.status != 200) {
                alert('file not found');
            } else {
                document.body.innerHTML = oEv.currentTarget.responseText;
            }
        }
 fnShowHumanFacePage();  };



    oXhr.send();
}